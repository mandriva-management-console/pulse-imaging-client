/* Copyright (C) 2010 - 2011 Broadcom Corporation.
 * Portions Copyright (C) VMware, Inc. 2007-2011. All Rights Reserved.
 */

struct tg3;

#ifndef TG3_VMWARE_NETQ_DISABLE
#define TG3_VMWARE_NETQ_ENABLE

#define TG3_MAX_NIC		32
#define TG3_OPTION_UNSET	-1

static unsigned int __devinitdata tg3_netq_index;
static int __devinitdata tg3_netq_force[TG3_MAX_NIC+1] =
			 { [0 ... TG3_MAX_NIC] = TG3_OPTION_UNSET };

module_param_array_named(force_netq, tg3_netq_force, int, NULL, 0);
MODULE_PARM_DESC(force_netq,
"Force the maximum number of NetQueues available per port (NetQueue capable devices only)");

static const struct {
	const char string[ETH_GSTRING_LEN];
} tg3_vmware_ethtool_stats_keys[] = {
	{ "[0]: rx_packets (sw)" },
	{ "[0]: rx_packets (hw)" },
	{ "[0]: rx_bytes (sw)" },
	{ "[0]: rx_bytes (hw)" },
	{ "[0]: rx_errors (sw)" },
	{ "[0]: rx_errors (hw)" },
	{ "[0]: rx_crc_errors" },
	{ "[0]: rx_frame_errors" },
	{ "[0]: tx_bytes" },
	{ "[0]: tx_ucast_packets" },
	{ "[0]: tx_mcast_packets" },
	{ "[0]: tx_bcast_packets" },

	{ "[1]: rx_packets (sw)" },
	{ "[1]: rx_packets (hw)" },
	{ "[1]: rx_bytes (sw)" },
	{ "[1]: rx_bytes (hw)" },
	{ "[1]: rx_errors (sw)" },
	{ "[1]: rx_errors (hw)" },
	{ "[1]: rx_crc_errors" },
	{ "[1]: rx_frame_errors" },
	{ "[1]: tx_bytes" },
	{ "[1]: tx_ucast_packets" },
	{ "[1]: tx_mcast_packets" },
	{ "[1]: tx_bcast_packets" },

	{ "[2]: rx_packets (sw)" },
	{ "[2]: rx_packets (hw)" },
	{ "[2]: rx_bytes (sw)" },
	{ "[2]: rx_bytes (hw)" },
	{ "[2]: rx_errors (sw)" },
	{ "[2]: rx_errors (hw)" },
	{ "[2]: rx_crc_errors" },
	{ "[2]: rx_frame_errors" },
	{ "[2]: tx_bytes" },
	{ "[2]: tx_ucast_packets" },
	{ "[2]: tx_mcast_packets" },
	{ "[2]: tx_bcast_packets" },

	{ "[3]: rx_packets (sw)" },
	{ "[3]: rx_packets (hw)" },
	{ "[3]: rx_bytes (sw)" },
	{ "[3]: rx_bytes (hw)" },
	{ "[3]: rx_errors (sw)" },
	{ "[3]: rx_errors (hw)" },
	{ "[3]: rx_crc_errors" },
	{ "[3]: rx_frame_errors" },
	{ "[3]: tx_bytes" },
	{ "[3]: tx_ucast_packets" },
	{ "[3]: tx_mcast_packets" },
	{ "[3]: tx_bcast_packets" },

	{ "[4]: rx_packets (sw)" },
	{ "[4]: rx_packets (hw)" },
	{ "[4]: rx_bytes (sw)" },
	{ "[4]: rx_bytes (hw)" },
	{ "[4]: rx_errors (sw)" },
	{ "[4]: rx_errors (hw)" },
	{ "[4]: rx_crc_errors" },
	{ "[4]: rx_frame_errors" },
	{ "[4]: tx_bytes" },
	{ "[4]: tx_ucast_packets" },
	{ "[4]: tx_mcast_packets" },
	{ "[4]: tx_bcast_packets" },

	{ "[5]: rx_packets (sw)" },
	{ "[5]: rx_packets (hw)" },
	{ "[5]: rx_bytes (sw)" },
	{ "[5]: rx_bytes (hw)" },
	{ "[5]: rx_errors (sw)" },
	{ "[5]: rx_errors (hw)" },
	{ "[5]: rx_crc_errors" },
	{ "[5]: rx_frame_errors" },
	{ "[5]: tx_bytes" },
	{ "[5]: tx_ucast_packets" },
	{ "[5]: tx_mcast_packets" },
	{ "[5]: tx_bcast_packets" },

	{ "[6]: rx_packets (sw)" },
	{ "[6]: rx_packets (hw)" },
	{ "[6]: rx_bytes (sw)" },
	{ "[6]: rx_bytes (hw)" },
	{ "[6]: rx_errors (sw)" },
	{ "[6]: rx_errors (hw)" },
	{ "[6]: rx_crc_errors" },
	{ "[6]: rx_frame_errors" },
	{ "[6]: tx_bytes" },
	{ "[6]: tx_ucast_packets" },
	{ "[6]: tx_mcast_packets" },
	{ "[6]: tx_bcast_packets" },

	{ "[7]: rx_packets (sw)" },
	{ "[7]: rx_packets (hw)" },
	{ "[7]: rx_bytes (sw)" },
	{ "[7]: rx_bytes (hw)" },
	{ "[7]: rx_errors (sw)" },
	{ "[7]: rx_errors (hw)" },
	{ "[7]: rx_crc_errors" },
	{ "[7]: rx_frame_errors" },
	{ "[7]: tx_bytes" },
	{ "[7]: tx_ucast_packets" },
	{ "[7]: tx_mcast_packets" },
	{ "[7]: tx_bcast_packets" },

	{ "[8]: rx_packets (sw)" },
	{ "[8]: rx_packets (hw)" },
	{ "[8]: rx_bytes (sw)" },
	{ "[8]: rx_bytes (hw)" },
	{ "[8]: rx_errors (sw)" },
	{ "[8]: rx_errors (hw)" },
	{ "[8]: rx_crc_errors" },
	{ "[8]: rx_frame_errors" },
	{ "[8]: tx_bytes" },
	{ "[8]: tx_ucast_packets" },
	{ "[8]: tx_mcast_packets" },
	{ "[8]: tx_bcast_packets" },

	{ "[9]: rx_packets (sw)" },
	{ "[9]: rx_packets (hw)" },
	{ "[9]: rx_bytes (sw)" },
	{ "[9]: rx_bytes (hw)" },
	{ "[9]: rx_errors (sw)" },
	{ "[9]: rx_errors (hw)" },
	{ "[9]: rx_crc_errors" },
	{ "[9]: rx_frame_errors" },
	{ "[9]: tx_bytes" },
	{ "[9]: tx_ucast_packets" },
	{ "[9]: tx_mcast_packets" },
	{ "[9]: tx_bcast_packets" },

	{ "[10]: rx_packets (sw)" },
	{ "[10]: rx_packets (hw)" },
	{ "[10]: rx_bytes (sw)" },
	{ "[10]: rx_bytes (hw)" },
	{ "[10]: rx_errors (sw)" },
	{ "[10]: rx_errors (hw)" },
	{ "[10]: rx_crc_errors" },
	{ "[10]: rx_frame_errors" },
	{ "[10]: tx_bytes" },
	{ "[10]: tx_ucast_packets" },
	{ "[10]: tx_mcast_packets" },
	{ "[10]: tx_bcast_packets" },

	{ "[11]: rx_packets (sw)" },
	{ "[11]: rx_packets (hw)" },
	{ "[11]: rx_bytes (sw)" },
	{ "[11]: rx_bytes (hw)" },
	{ "[11]: rx_errors (sw)" },
	{ "[11]: rx_errors (hw)" },
	{ "[11]: rx_crc_errors" },
	{ "[11]: rx_frame_errors" },
	{ "[11]: tx_bytes" },
	{ "[11]: tx_ucast_packets" },
	{ "[11]: tx_mcast_packets" },
	{ "[11]: tx_bcast_packets" },

	{ "[12]: rx_packets (sw)" },
	{ "[12]: rx_packets (hw)" },
	{ "[12]: rx_bytes (sw)" },
	{ "[12]: rx_bytes (hw)" },
	{ "[12]: rx_errors (sw)" },
	{ "[12]: rx_errors (hw)" },
	{ "[12]: rx_crc_errors" },
	{ "[12]: rx_frame_errors" },
	{ "[12]: tx_bytes" },
	{ "[12]: tx_ucast_packets" },
	{ "[12]: tx_mcast_packets" },
	{ "[12]: tx_bcast_packets" },

	{ "[13]: rx_packets (sw)" },
	{ "[13]: rx_packets (hw)" },
	{ "[13]: rx_bytes (sw)" },
	{ "[13]: rx_bytes (hw)" },
	{ "[13]: rx_errors (sw)" },
	{ "[13]: rx_errors (hw)" },
	{ "[13]: rx_crc_errors" },
	{ "[13]: rx_frame_errors" },
	{ "[13]: tx_bytes" },
	{ "[13]: tx_ucast_packets" },
	{ "[13]: tx_mcast_packets" },
	{ "[13]: tx_bcast_packets" },

	{ "[14]: rx_packets (sw)" },
	{ "[14]: rx_packets (hw)" },
	{ "[14]: rx_bytes (sw)" },
	{ "[14]: rx_bytes (hw)" },
	{ "[14]: rx_errors (sw)" },
	{ "[14]: rx_errors (hw)" },
	{ "[14]: rx_crc_errors" },
	{ "[14]: rx_frame_errors" },
	{ "[14]: tx_bytes" },
	{ "[14]: tx_ucast_packets" },
	{ "[14]: tx_mcast_packets" },
	{ "[14]: tx_bcast_packets" },

	{ "[15]: rx_packets (sw)" },
	{ "[15]: rx_packets (hw)" },
	{ "[15]: rx_bytes (sw)" },
	{ "[15]: rx_bytes (hw)" },
	{ "[15]: rx_errors (sw)" },
	{ "[15]: rx_errors (hw)" },
	{ "[15]: rx_crc_errors" },
	{ "[15]: rx_frame_errors" },
	{ "[15]: tx_bytes" },
	{ "[15]: tx_ucast_packets" },
	{ "[15]: tx_mcast_packets" },
	{ "[15]: tx_bcast_packets" },

	{ "[16]: rx_packets (sw)" },
	{ "[16]: rx_packets (hw)" },
	{ "[16]: rx_bytes (sw)" },
	{ "[16]: rx_bytes (hw)" },
	{ "[16]: rx_errors (sw)" },
	{ "[16]: rx_errors (hw)" },
	{ "[16]: rx_crc_errors" },
	{ "[16]: rx_frame_errors" },
	{ "[16]: tx_bytes" },
	{ "[16]: tx_ucast_packets" },
	{ "[16]: tx_mcast_packets" },
	{ "[16]: tx_bcast_packets" },
};

/*
 * Pack this structure so that we don't get an extra 8 bytes
 * should this driver be built for a 128-bit CPU. :)
 */
struct tg3_netq_stats {
	u64	rx_packets_sw;
	u64	rx_packets_hw;
	u64	rx_bytes_sw;
	u64	rx_bytes_hw;
	u64	rx_errors_sw;
	u64	rx_errors_hw;
	u64	rx_crc_errors;
	u64	rx_frame_errors;
	u64	tx_bytes;
	u64	tx_ucast_packets;
	u64	tx_mcast_packets;
	u64	tx_bcast_packets;
} __attribute__((packed));

#define TG3_NETQ_NUM_STATS	(sizeof(struct tg3_netq_stats)/sizeof(u64))

struct tg3_netq_napi {
	u32			flags;
	#define TG3_NETQ_TXQ_ALLOCATED		0x0001
	#define TG3_NETQ_RXQ_ALLOCATED		0x0002
	#define TG3_NETQ_RXQ_ENABLED		0x0008
	#define TG3_NETQ_TXQ_FREE_STATE		0x0010
	#define TG3_NETQ_RXQ_FREE_STATE		0x0020

	struct tg3_netq_stats	stats;
	struct net_device_stats	net_stats;
};

struct tg3_vmware_netq {
	u16			n_tx_queues_allocated;
	u16			n_rx_queues_allocated;

	u32			index;
};

static void tg3_vmware_fetch_stats(struct tg3 *tp);
static void tg3_disable_prod_rcbs(struct tg3 *tp, u32 ring);
static void tg3_setup_prod_mboxes(struct tg3 *tp, u32 ring);
static void tg3_netq_init(struct tg3 *tp);
static void tg3_netq_free_all_qs(struct tg3 *tp);
static void tg3_netq_invalidate_state(struct tg3 *tp);
static void tg3_netq_restore(struct tg3 *tp);
static int  tg3_netq_stats_size(struct tg3 *tp);
static void tg3_netq_stats_get(struct tg3 *tp, u64 *tmp_stats);
static void tg3_netq_stats_clear(struct tg3 *tp);
#endif /* TG3_VMWARE_NETQ_ENABLE */

struct tg3_vmware {
	u32 rx_mode_reset_counter;

#ifdef TG3_VMWARE_NETQ_ENABLE
	struct tg3_vmware_netq	netq;
#endif
};

#if !defined(TG3_VMWARE_BMAPILNX_DISABLE)

#include "esx_ioctl.h"

static int
tg3_vmware_ioctl_cim(struct net_device *dev, struct ifreq *ifr);

#endif  /* !TG3_VMWARE_BMAPILNX_DISABLED */

static void tg3_vmware_timer(struct tg3 *tp);
