/*
 * Copyright 2000 Hans Reiser
 */

#define REISERFSPROGS_VERSION "3.x.0i"

#define print_banner(prog) \
fprintf (stderr, "\n<-------------%s, 2001------------->\nreiserfsprogs %s\n", \
prog, REISERFSPROGS_VERSION)
