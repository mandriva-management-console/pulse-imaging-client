#ifndef _JFS_USER_H
#define _JFS_USER_H

typedef unsigned short kdev_t;

#include <linux/jfs.h>


#endif /* _JFS_USER_H */
