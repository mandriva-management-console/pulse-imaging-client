#include "tinylogin.h"

const char usage_messages[] =

#define MAKE_USAGE
#include "usage.h"

#include "applets.h"

;
